const uploadPath = process.env.VUE_APP_BASE_API + 'upload/upload'
export { uploadPath }
